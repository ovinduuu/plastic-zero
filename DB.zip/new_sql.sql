-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 10, 2019 at 02:18 PM
-- Server version: 5.5.20
-- PHP Version: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `garbagecollection`
--

-- --------------------------------------------------------

--
-- Table structure for table `dailyvalue`
--

CREATE TABLE IF NOT EXISTS `dailyvalue` (
  `id` varchar(20) NOT NULL,
  `price` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dailyvalue`
--

INSERT INTO `dailyvalue` (`id`, `price`) VALUES
('adminvalue', 156);

-- --------------------------------------------------------

--
-- Table structure for table `dataentry`
--

CREATE TABLE IF NOT EXISTS `dataentry` (
  `id` varchar(5) NOT NULL,
  `amount` float NOT NULL,
  `kg` varchar(50) NOT NULL,
  `dailyvalue` float NOT NULL,
  `Date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ref` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`ref`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `dataentry`
--

INSERT INTO `dataentry` (`id`, `amount`, `kg`, `dailyvalue`, `Date`, `ref`) VALUES
('ST001', 936, '6', 156, '2019-06-01 06:40:44', 18),
('ST002', 1404, '9', 156, '2019-06-01 06:40:53', 19),
('ST001', 936, '6', 156, '2019-06-01 06:41:00', 20);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `id` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `telno` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `TAmount` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `name`, `telno`, `password`, `TAmount`) VALUES
('ST001', 'Dilshan', '0715486954', 'dil789', 1872),
('ST002', 'Nihara', '0368895456', 'Aksni28', 1404),
('ST003', 'Samudu', '0725689785', 'Chanu404', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `user_id` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `password`, `type`) VALUES
('admin', 'admin', 'admin'),
('User001', 'cha02', 'user'),
('User002', 'dil789', 'user'),
('User003', 'OvIN22396', 'user');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
